/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hidethefilegui;

/**
 *
 * @author Smit
 */
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;

public class DataGetter
{
    BufferedImage bimg;
    Color c;
    public static void main(String[] args)
    throws IOException
    {
    //DataGetter sg = new DataGetter();
    //sg.get(new File("image.bmp") , new File("TargetDataimg.png"));
    }
    
    public void get(File imageFile , File target)
    throws IOException
    {
    int r,g,b;
    int size;
    bimg = ImageIO.read(imageFile);
    //File dataFile = new File("TargetDataimg.png");
    FileOutputStream fos = new FileOutputStream(target);
//	*********************Read File Size From (0,0) Pixel.*********************
    {
    c = new Color(bimg.getRGB(0,0));
    r=c.getRed();
    g=c.getGreen();
    b=c.getBlue();
    size = b | (g << 8) | (r << 16);
    //	System.out.println("R="+r+" | g=" + g + " | B=" + b + " | size="+size);
    }
//	**************************************************************************
    System.out.println("Processing...");
    int x=1,y=0;
    for(int j=0;j<size;j++)
    {
        int a=0;	// counter for shift
        int i=0;	// used to form and hold target byte
        for(int k=0;k<3;k++)	// K represents Group of 3 Pixels that can accomodate 9 bits.
        {
            //	System.out.println("\nIteration"+k+" A="+a);
            //	System.out.println("X="+x + " y="+y+" | ");
            c = new Color(bimg.getRGB(x,y));
            r=c.getRed();
            g=c.getGreen();
            b=c.getBlue();
			
            i= i | ( (r & 1)<<a) ;
            a++;
            //	System.out.print(" i="+Integer.toBinaryString(i));
            i = i |( (g & 1)<<a );
            a++;
            //	System.out.print(" i="+Integer.toBinaryString(i));
            if(k!=2)
            {
                i = i | ((b & 1)<<a );
		a++;
		//		System.out.println(" i="+Integer.toBinaryString(i) + " A="+a);
            }
            else
            {
                a=0;
            }
            x++;
            if(x >= bimg.getWidth())
            {
                x=0;
                y++;
                if(y>= bimg.getHeight())
                {
                    System.out.println("Error : End Of Image.");
                    System.exit(1);
                    //break;
                }
            }
        }
        //System.out.println();					
        //System.out.println("Final i bits="+Integer.toBinaryString(i)+ "i="+i);
        fos.write(i);
        //System.out.println("Final i=" + (char) i +" = " + Integer.toBinaryString(i));
    }	
    System.out.println("Success.");
    fos.close();
    }

}
