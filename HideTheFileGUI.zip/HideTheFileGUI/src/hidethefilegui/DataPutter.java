/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hidethefilegui;

/**
 *
 * @author Smit
 */
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Color;
import javax.swing.JProgressBar;

class DataPutter {
	BufferedImage bimg;
	Color c;

	public static void main(String[] args)
	throws IOException
	{
		//DataPutter sp = new DataPutter();
		//sp.put(new File("java.bmp"), new File("dataimg.png"));

	}
	
	public void put(File imageFile , File dataFile ,File output , int ext ,JProgressBar PBar)
	throws IOException
	{
		int r,g,b;
		
		bimg = ImageIO.read(imageFile);
		FileInputStream fis = new FileInputStream(dataFile);
//	****************Store File Size In (0,0) Pixel.****************************		
		int size=0;
		if(dataFile.length()<= Integer.MAX_VALUE && dataFile.length()<= 1_67_77_000)
		{
			//size=0x00FFFFF2;
			size=(int)dataFile.length();
		//	System.out.println("Limit=" + Integer.MAX_VALUE + " | i="+size);
		//	System.out.println("Hight=" + bimg.getHeight() + " Width="+bimg.getWidth());
		}
		else
		{
			System.out.println("Error : File Size Larger than limit!");
			System.exit(1);
		}
		r = (size & 0x00FF0000)>>16;
		g = (size & 0x0000FF00)>>8;
		b = size & 0x000000FF;
		//System.out.println("R="+r+" | g=" + g + " | B=" + b);
		c=new Color(r, g, b);
		bimg.setRGB(0, 0, c.getRGB());
		
//  ***********************************************************************		
		System.out.println("Processing...");
		int dat;
		int x=1,y=0;
		
		//System.out.println("Initially="+fis.available());
		int fi=fis.available();
                PBar.setValue((fi-fis.available())*100/fi);
		while( ( dat=fis.read() ) != -1)
		{
                    PBar.setValue((fi-fis.available())*100/fi);
			//System.out.println( (fi-fis.available())*100/fi );
                    for(int k=0;k<3;k++)	// K represents Group of 3 Pixels that can accomodate 9 bits.
                    {
			//System.out.println("X="+x + " y="+y+" | ");
			c = new Color(bimg.getRGB(x,y));
			r=c.getRed();
			g=c.getGreen();
			b=c.getBlue();
				
			//System.out.println("dat="+Integer.toBinaryString(dat));
			r = (r&0xFFFFFFFE) | (dat & 1);
			dat = dat>>1;
			//System.out.println("dat="+Integer.toBinaryString(dat)+" r="+Integer.toBinaryString(r));
			g = (g&0xFFFFFFFE) | (dat & 1);
			dat = dat >> 1;
			//System.out.println("dat="+Integer.toBinaryString(dat)+" g="+Integer.toBinaryString(g));
			if(k!=2)
			{
                            b = (b&0xFFFFFFFE) | (dat & 1);
			dat = dat >> 1;
			//System.out.println("dat="+Integer.toBinaryString(dat)+" b="+Integer.toBinaryString(b));
			}
			bimg.setRGB(x, y, new Color(r,g,b).getRGB());
			
			x++;
			if(x >= bimg.getWidth())
			{
			x=0;
			y++;
                            if(y>= bimg.getHeight())
                            {
                                System.out.println("Error : End Of Image :- Carrier File is small to hold data!");
                                System.exit(1);
                            }
			}
                    }
		}
                
	if (ext == 0)
        {
            String s1 = output.getPath() + ".jpg" ;
            ImageIO.write(bimg, "jpg", new File(s1));
        }    
            
        else if(ext == 1)
        {    
            String s2 = output.getPath() + ".gif" ;
            ImageIO.write(bimg, "gif", new File(s2));
        }
        else
        {
            String s3 = output.getPath() + ".bmp" ;
            ImageIO.write(bimg, "bmp", new File(s3));
        }
        
        System.out.println("Success");
        fis.close();
	}

}
